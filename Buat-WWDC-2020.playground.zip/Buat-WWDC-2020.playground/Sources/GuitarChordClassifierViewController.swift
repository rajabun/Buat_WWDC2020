import UIKit
import PlaygroundSupport
import CoreML
import AVFoundation
import SoundAnalysis

class GuitarChordClassifierViewController: UIViewController
{
    let guitarModel = GuitarChordClassifier()
    
    // Create a new audio engine.
    let audioEngine = AVAudioEngine()
    
    func startAudioEngine()
    {
        var chordModel: MLModel = guitarModel.model
        
        do
        {
            // Start the stream of audio data.
            try audioEngine.start()
        }
        catch
        {
            print("Unable to start AVAudioEngine: \(error.localizedDescription)")
        }
        
        // Get the native audio format of the engine's input bus.
        let inputFormat = audioEngine.inputNode.inputFormat(forBus: 0)

        // Create a new stream analyzer.
        var streamAnalyzer = SNAudioStreamAnalyzer(format: inputFormat)
        
        // Create a new observer that will be notified of analysis results.
        // Keep a strong reference to this object.
        let resultsObserver = ResultsObserver()

        do
        {
            // Prepare a new request for the trained model.
            let request = try SNClassifySoundRequest(mlModel: chordModel)
            try streamAnalyzer.add(request, withObserver: resultsObserver)
        }
        catch
        {
            print("Unable to prepare request: \(error.localizedDescription)")
            return
        }
        
        // Serial dispatch queue used to analyze incoming audio buffers.
        let analysisQueue = DispatchQueue(label: "com.apple.AnalysisQueue")
        
        // Install an audio tap on the audio engine's input node.
        audioEngine.inputNode.installTap(onBus: inputBus,
                                         bufferSize: 8192, // 8k buffer
                                         format: inputFormat)
        { buffer, time in
            
            // Analyze the current audio buffer.
            self.analysisQueue.async
            {
                self.streamAnalyzer.analyze(buffer, atAudioFramePosition: time.sampleTime)
            }
        }
    }
    
    func createNewStreamAnalyzer()
    {
        
    }
    
    func createNewObserver()
    {
        
    }
    
    func analyzeStreamAudio()
    {
        
    }
}

// Observer object that is called as analysis results are found.
class ResultsObserver : NSObject, SNResultsObserving
{
    
    func request(_ request: SNRequest, didProduce result: SNResult)
    {
        
        // Get the top classification.
        guard let result = result as? SNClassificationResult,
            let classification = result.classifications.first else { return }
        
        // Determine the time of this result.
        let formattedTime = String(format: "%.2f", result.timeRange.start.seconds)
        print("Analysis result for audio at time: \(formattedTime)")
        
        let confidence = classification.confidence * 100.0
        let percent = String(format: "%.2f%%", confidence)

        // Print the result as Instrument: percentage confidence.
        print("\(classification.identifier): \(percent) confidence.\n")
    }
    
    func request(_ request: SNRequest, didFailWithError error: Error)
    {
        print("The the analysis failed: \(error.localizedDescription)")
    }
    
    func requestDidComplete(_ request: SNRequest)
    {
        print("The request completed successfully!")
    }
}

